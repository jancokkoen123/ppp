Help the docs
=====

If you want to help develop the documentation,
join our discord, https://discord.gg/MttV6XVwTQ and acquire the role to see Koyn channels,
after that go to ``#roles-koyn`` and get the role of Beta Tester,
after that go to the ``#Beta-tools`` channel and ask for access to write pages in the bot documentation.

.. note::

   Is necessary to have a github account !
