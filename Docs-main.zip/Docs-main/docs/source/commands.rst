Commands
=====

.. _help:

Help
------------

With the command /help you can see a list of commands the bot currently has.

.. code-block:: console

   /help



Different type of helps
----------------

The bot also has others helps commands, for example the /helpadmin

The ``/helpadmin`` show you all the commands the admin can use,
while the ``/helpsub`` show you all the commands about subs.
