Welcome to Koyn documentation !
===================================

**Koyn** is a discord data visualization bot for the game albion online
You can join the documentation development team and help to develop our documentation !
`to do that follow the steps on this page <https://world.openfoodfacts.org/>`_

.. note::

   This project is under active development and all the content written here are from the community and revision may be necessary.

Contents
--------

.. toctree::

   commands
   joinus
