Documentation written by the community
=======================================
.. image:: Images/logo.png

This project is the documentation about how to use the Koyn bot, written by the community and will be incorporated into the Koyn bot official website later.

If you want to help this documentation develop, join our discord: https://discord.gg/MttV6XVwTQ

acquire the role to see the Koyn channels and then go to #roles-koyn and acquire the Beta role and ask for access to the documentation on the channel #Beta-tools
